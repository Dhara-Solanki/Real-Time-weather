package np.com.bimalkafle.realtimeweather.api

data class WeatherModel(
    val current: Current,
    val location: Location
)