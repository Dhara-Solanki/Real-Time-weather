package np.com.bimalkafle.realtimeweather.api

object Constant {

    val apiKey = "766df210725c48e6994142350250304"
}